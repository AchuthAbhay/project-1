from flask import Flask, render_template

app = Flask(__name__, template_folder='templates', static_folder='static')

# Routes for each HTML file
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/products')
def products():
    return render_template('product.html')

@app.route('/product-details')
def product_details():
    return render_template('product-details.html')

@app.route('/product-image-upload')
def product_image_upload():
    return render_template('product-image-upload.html')

@app.route('/services')
def services():
    return render_template('service.html')

if __name__ == '__main__':
    app.run(debug=True)
