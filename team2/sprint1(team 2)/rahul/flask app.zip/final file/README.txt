This is RAHUL SANSKRITAYAN, all the folder here are made by me which should be done by the Parth. I have Implement the
Figma design as an HTML template using Flask.
Parth have not done anything in this project. And This project that which I have shown you and have not worked that time
due to network and some issue. But after meeting it is working properly and Database is not integrated in this folder.
And I have final year project.It is not possible for me to spend too much time.
As I am college representative(HEAD BOY of my College). So, I am busy with college programs and activity.